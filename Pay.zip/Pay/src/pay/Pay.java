/*
 * Donglin Xiong
 *This program is a payroll calculation program.
 *CSC206
 *2/21/2024
 */
package pay;

import java.util.Scanner;

public class Pay {

    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner input = new Scanner(System.in);

        int hours = 0; // The hours worked
        double payRate = 0; // Pay rate per hour
        double pay = 0; // Initialize pay variable

        // Prompt the user for input
        System.out.print("Enter the number of hours worked: ");
        hours = input.nextInt(); // Read hours worked as an integer

        System.out.print("Enter the pay rate: ");
        payRate = input.nextDouble(); // Read pay rate
        
        if (hours >= 0 && payRate >= 0){ 
        // Calculate pay
            if (hours <= 40) {
            // Calculate gross pay for hours up to 40
                pay = hours * payRate;
            } else {
            // Calculate gross pay for hours over 40 with overtime rate
                pay = (hours - 40) * (1.5 * payRate) + 40 * payRate;
            }
        
        
        // Display the gross pay
        System.out.println("Gross pay: $" + pay);
        }else{ 
            System.out.println("please enter positive values for hours and pay rate.");
        }
    }
}

