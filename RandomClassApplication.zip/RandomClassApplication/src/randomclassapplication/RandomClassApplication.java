/*
 * Following textbook example 
 */
package randomclassapplication;

import java.util.Random;

/**
 *
 * @author donglinxiong
 */
public class RandomClassApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random randGen = new Random();
        int rowNumL;
        int colNumL;

        int rowNumR;
        int colNumR;

        //Switch a student from random seat on the left(Cols 1 to 15)
        //to the right random seat(cols 16 to 30)
        //Seat row are 1 to 20
        rowNumL = randGen.nextInt(20) + 1; //1 to 20
        colNumL = randGen.nextInt(15) + 1; // 1 to 15

        rowNumR = randGen.nextInt(20) + 1; //1 to 20
        colNumR = randGen.nextInt(15) + 1; //16 to 30

        System.out.print("Move from ");
        System.out.print("row " + rowNumL + " col " + colNumL);
        System.out.print(" to ");
        System.out.println("row " + rowNumR + " col " + colNumR);
    }

}
