/*
 * Donglin Xiong
 * This program create a mirrored matrix out of even numbers up to user value
 */
package mirrored.matrix;

/**
 *
 * @author donglinxiong
 */

import java.util.Scanner;


public class MirroredMatrix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //prompt the user to enter the number of rows
         Scanner input = new Scanner(System.in);
         
        int number_rows = 0;
        int number_columns = 0;
        int mirroredMatrix;
        
        System.out.print("Enter number of rows: ");
        number_rows = input.nextInt();
       
            

       System.out.print("Enter number of columns: ");
        number_columns= input.nextInt();
        
        

        mirroredMatrix = 2 * number_rows-(number_rows-number_columns)*2;
        

        System.out.print(mirroredMatrix);
        
        
    }
    
}
