/*
 * Donglin Xiong
 *This program is taking user input for number of rows and columns and display
 *a rectangular pattern of pound sings.
 * CSC 206 
 *2/24/2024
 */
package rectangulardisplay;

import java.util.Scanner;

public class RectangularDisplay {

    public static void main(String[] args) {
        
        //Scanner object  with variable "input"
        //initialized variable with System.in
        Scanner input = new Scanner(System.in);
        
        //prompt user input
        System.out.print("Enter the number of rows: ");
        //read integer input and stores it in variable"n"
        int n = input.nextInt();
        
        //prompt user input
        System.out.print("Enter the number of columns: ");
        //read integer input and stores it in variable"m"
        int m = input.nextInt();
        
        //starting for loop 
        //i incrementing by 1 when the condition is met.
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                //Print out "#"
                System.out.print("#");
            }
            System.out.println();
            // ended the for loop
        }
    }
}
