/*
 *Donglin Xiong
 *This program is use to calculate the change to 
 *be returned from a customer's purchase.
 * CSC206
 *2/22/2024
*/


package changeback;

import java.util.Scanner;

public class Changeback {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Received the amount
        System.out.print("Enter amount of ticket: ");
        double ticket_amount = input.nextDouble();//variable "ticket_amount"

        // Received the tendered amount
        System.out.print("Enter amount tendered: ");
        double tender_amount = input.nextDouble();//variable "tender_amount"
        
        //calculate change of amount 
        double change_amount = tender_amount - ticket_amount;
        
        //convert remain amount into cents in total
        //now the remaining amount is $1 *100 = 100 cents.
        int remainingAmount = (int) (change_amount * 100);
 
        //find the number of one dollars
        int numberOfOneDollars = remainingAmount / 100;
        remainingAmount %= 100;//remove one dollar and keep remain.
        
        //find the number of quaters
        int numberOfQuarters = remainingAmount / 25;
        remainingAmount %= 25;//remove one quarter and keep remain.

        //find the number of dimes
        int numberOfDimes = remainingAmount / 10;
        remainingAmount %= 10;//remove one dimes and keep remain.
 
        //find the number of nickels
        int numberOfNickels = remainingAmount / 5;
        remainingAmount %= 5;//remove nickels and keep remain.

        int numberOfPennies = remainingAmount;

        // Display the result
        System.out.println("Customer's ticket: $" + ticket_amount);
        System.out.println("Customer tendered: $" + tender_amount);
        System.out.println("Customer's change: $" + change_amount);
        System.out.println("Please give the customer back:");
        System.out.println("Dollars: " + numberOfOneDollars);
        System.out.println("Quarters: " + numberOfQuarters);
        System.out.println("Dimes: " + numberOfDimes);
        System.out.println("Nickels: " + numberOfNickels);
        System.out.println("Pennies: " + numberOfPennies);
    }
}
